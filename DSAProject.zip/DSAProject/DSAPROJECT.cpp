#include <iostream>
#include <algorithm>
using namespace std;

class Node {
public:
    int data;
    bool color; // true for RED, false for BLACK
    Node* left, * right, * parent;

    Node(int data) {
        this->data = data;
        left = right = parent = nullptr;
        this->color = true; // New nodes are always red
    }
};

class RBTree {
private:
    Node* root;

    void rotateLeft(Node*& root, Node*& pt) {
        Node* pt_right = pt->right;
        pt->right = pt_right->left;
        if (pt_right->left != nullptr)
            pt_right->left->parent = pt;
        pt_right->parent = pt->parent;
        if (pt->parent == nullptr)
            root = pt_right;
        else if (pt == pt->parent->left)
            pt->parent->left = pt_right;
        else
            pt->parent->right = pt_right;
        pt->parent = pt_right;
        pt_right->left = pt;
    }

    void rotateRight(Node*& root, Node*& pt) {
        Node* pt_left = pt->left;
        pt->left = pt_left->right;
        if (pt_left->right != nullptr)
            pt_left->right->parent = pt;
        pt_left->parent = pt->parent;
        if (pt->parent == nullptr)
            root = pt_left;
        else if (pt == pt->parent->left)
            pt->parent->left = pt_left;
        else
            pt->parent->right = pt_left;
        pt->parent = pt_left;
        pt_left->right = pt;
    }

    void fixInsert(Node*& root, Node*& pt) {
        Node* parent_pt = nullptr;
        Node* grand_parent_pt = nullptr;

        while (pt != root && pt->parent->color == true) {
            parent_pt = pt->parent;
            grand_parent_pt = pt->parent->parent;

            if (parent_pt == grand_parent_pt->left) {
                Node* uncle_pt = grand_parent_pt->right;

                if (uncle_pt != nullptr && uncle_pt->color == true) {
                    grand_parent_pt->color = true;
                    parent_pt->color = false;
                    uncle_pt->color = false;
                    pt = grand_parent_pt;
                }
                else {
                    if (pt == parent_pt->right) {
                        rotateLeft(root, parent_pt);
                        pt = parent_pt;
                        parent_pt = pt->parent;
                    }
                    rotateRight(root, grand_parent_pt);
                    swap(parent_pt->color, grand_parent_pt->color);
                    pt = parent_pt;
                }
            }
            else {
                Node* uncle_pt = grand_parent_pt->left;

                if (uncle_pt != nullptr && uncle_pt->color == true) {
                    grand_parent_pt->color = true;
                    parent_pt->color = false;
                    uncle_pt->color = false;
                    pt = grand_parent_pt;
                }
                else {
                    if (pt == parent_pt->left) {
                        rotateRight(root, parent_pt);
                        pt = parent_pt;
                        parent_pt = pt->parent;
                    }
                    rotateLeft(root, grand_parent_pt);
                    swap(parent_pt->color, grand_parent_pt->color);
                    pt = parent_pt;
                }
            }
        }
        root->color = false;
    }

    void fixDelete(Node*& root, Node*& x) {
        while (x != root && (x == nullptr || x->color == false)) {
            if (x == x->parent->left) {
                Node* w = x->parent->right;
                if (w->color == true) {
                    w->color = false;
                    x->parent->color = true;
                    rotateLeft(root, x->parent);
                    w = x->parent->right;
                }
                if ((w->left == nullptr || w->left->color == false) &&
                    (w->right == nullptr || w->right->color == false)) {
                    w->color = true;
                    x = x->parent;
                }
                else {
                    if (w->right == nullptr || w->right->color == false) {
                        if (w->left != nullptr) w->left->color = false;
                        w->color = true;
                        rotateRight(root, w);
                        w = x->parent->right;
                    }
                    w->color = x->parent->color;
                    x->parent->color = false;
                    if (w->right != nullptr) w->right->color = false;
                    rotateLeft(root, x->parent);
                    x = root;
                }
            }
            else {
                Node* w = x->parent->left;
                if (w->color == true) {
                    w->color = false;
                    x->parent->color = true;
                    rotateRight(root, x->parent);
                    w = x->parent->left;
                }
                if ((w->left == nullptr || w->left->color == false) &&
                    (w->right == nullptr || w->right->color == false)) {
                    w->color = true;
                    x = x->parent;
                }
                else {
                    if (w->left == nullptr || w->left->color == false) {
                        if (w->right != nullptr) w->right->color = false;
                        w->color = true;
                        rotateLeft(root, w);
                        w = x->parent->left;
                    }
                    w->color = x->parent->color;
                    x->parent->color = false;
                    if (w->left != nullptr) w->left->color = false;
                    rotateRight(root, x->parent);
                    x = root;
                }
            }
        }
        if (x != nullptr) x->color = false;
    }

    void inorderHelper(Node* root) const {
        if (root == nullptr)
            return;
        inorderHelper(root->left);
        cout << root->data << " ";
        inorderHelper(root->right);
    }

    void preorderHelper(Node* root) const {
        if (root == nullptr)
            return;
        cout << root->data << " ";
        preorderHelper(root->left);
        preorderHelper(root->right);
    }

    void postorderHelper(Node* root) const {
        if (root == nullptr)
            return;
        postorderHelper(root->left);
        postorderHelper(root->right);
        cout << root->data << " ";
    }

    int heightHelper(Node* node) const {
        if (node == nullptr)
            return 0;
        return 1 + max(heightHelper(node->left), heightHelper(node->right));
    }

    int diameterHelper(Node* node, int& height) {
        if (node == nullptr) {
            height = 0;
            return 0;
        }

        int lh = 0, rh = 0;
        int ldiameter = diameterHelper(node->left, lh);
        int rdiameter = diameterHelper(node->right, rh);

        height = max(lh, rh) + 1;

        return max(lh + rh + 1, max(ldiameter, rdiameter));
    }

    Node* minValueNode(Node* node) {
        Node* ptr = node;
        while (ptr->left != nullptr)
            ptr = ptr->left;
        return ptr;
    }

    Node* maxValueNode(Node* node) {
        Node* ptr = node;
        while (ptr->right != nullptr)
            ptr = ptr->right;
        return ptr;
    }

    Node* searchHelper(Node* root, int key) const {
        if (root == nullptr || root->data == key)
            return root;
        if (key < root->data)
            return searchHelper(root->left, key);
        return searchHelper(root->right, key);
    }

    Node* successorHelper(Node* node) {
        if (node->right != nullptr)
            return minValueNode(node->right);
        Node* p = node->parent;
        while (p != nullptr && node == p->right) {
            node = p;
            p = p->parent;
        }
        return p;
    }

    Node* predecessorHelper(Node* node) {
        if (node->left != nullptr)
            return maxValueNode(node->left);
        Node* p = node->parent;
        while (p != nullptr && node == p->left) {
            node = p;
            p = p->parent;
        }
        return p;
    }

    void deleteNodeHelper(Node*& root, Node*& z) {
        Node* y = z;
        Node* x = nullptr;
        bool y_original_color = y->color;

        if (z->left == nullptr) {
            x = z->right;
            transplant(root, z, z->right);
        }
        else if (z->right == nullptr) {
            x = z->left;
            transplant(root, z, z->left);
        }
        else {
            y = minValueNode(z->right);
            y_original_color = y->color;
            x = y->right;
            if (y->parent == z) {
                if (x != nullptr)
                    x->parent = y;
            }
            else {
                transplant(root, y, y->right);
                y->right = z->right;
                y->right->parent = y;
            }
            transplant(root, z, y);
            y->left = z->left;
            y->left->parent = y;
            y->color = z->color;
        }
        delete z;
        if (y_original_color == false)
            fixDelete(root, x);
    }

    void transplant(Node*& root, Node* u, Node* v) {
        if (u->parent == nullptr)
            root = v;
        else if (u == u->parent->left)
            u->parent->left = v;
        else
            u->parent->right = v;
        if (v != nullptr)
            v->parent = u->parent;
    }

public:
    RBTree() {
        root = nullptr;
    }

    void insert(const int& data) {
        Node* pt = new Node(data);
        root = BSTInsert(root, pt);
        fixInsert(root, pt);
    }

    void deleteNode(const int& data) {
        Node* node = searchHelper(root, data);
        if (node != nullptr) {
            deleteNodeHelper(root, node);
        }
    }

    Node* BSTInsert(Node* root, Node* pt) {
        if (root == nullptr)
            return pt;
        if (pt->data < root->data) {
            root->left = BSTInsert(root->left, pt);
            root->left->parent = root;
        }
        else if (pt->data > root->data) {
            root->right = BSTInsert(root->right, pt);
            root->right->parent = root;
        }
        return root;
    }

    void inorder() const {
        inorderHelper(root);
        cout << endl;
    }

    void preorder() const {
        preorderHelper(root);
        cout << endl;
    }

    void postorder() const {
        postorderHelper(root);
        cout << endl;
    }

    int height() const {
        return heightHelper(root);
    }

    int diameter() {
        int height = 0;
        return diameterHelper(root, height);
    }

    Node* search(int key) const {
        return searchHelper(root, key);
    }

    Node* successor(Node* node) {
        return successorHelper(node);
    }

    Node* predecessor(Node* node) {
        return predecessorHelper(node);
    }
};

int main() {
    RBTree tree;
    tree.insert(10);
    tree.insert(20);
    tree.insert(30);
    tree.insert(15);
    tree.insert(25);

    cout << "Inorder traversal: ";
    tree.inorder();

    cout << "Preorder traversal: ";
    tree.preorder();

    cout << "Postorder traversal: ";
    tree.postorder();

    cout << "Tree height: " << tree.height() << endl;
    cout << "Tree diameter: " << tree.diameter() << endl;

    tree.deleteNode(20);

    cout << "Inorder traversal after deletion: ";
    tree.inorder();

    return 0;
}
